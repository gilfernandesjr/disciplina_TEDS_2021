package com.example.android.webviewteste;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webview = (WebView) findViewById(R.id.webview);
        webview.loadUrl("https://www.google.com.br");
        webview.getSettings().setJavaScriptEnabled(true); //habilita os interpretadores de Javascript do WebView
        webview.setWebViewClient(new WebViewClient()); //troca o WebViewClient para um novo definido no código

        //String html = "<html><body>Hello World WebView</body></html>";
        //webview.loadData(html, "text/html", "UTF-8");
    }
}