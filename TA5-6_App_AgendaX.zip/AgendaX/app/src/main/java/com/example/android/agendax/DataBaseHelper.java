package com.example.android.agendax;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String banco_dados = "Contatos";
    private  static  int versao = 1;

    public DataBaseHelper(Context context){
        super(context, banco_dados, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL( "CREATE TABLE AGENDA (ID INTEGER PRIMARY KEY,"+
                "NOME VARCHAR(30)," +
                "EMPRESA VARCHAR(30)," +
                "UF VARCHAR(2))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

       /* if (i < 2)
            db.execSQL("ALTER TABLE AGENDA ADD COLUMN TESTE INTEGER");
        if (i < 3)
            db.execSQL("ALTER TABLE AGENDA ADD COLUMN TESTE2 INTEGER");
        if (i < 4)
            db.execSQL("CREATE TABLE TAB (ID_TAB INTEGER PRIMARY KEY,"+
                    "NOME VARCHAR(30))" );
                    */




    }



    public long addAgenda(Agenda a){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("NOME",a.getNome());
        values.put("EMPRESA",a.getEmpresa());
        values.put("UF",a.getUf());

        long id = db.insert("AGENDA",null, values);

        return id;
    }

    public long updateAgenda(Agenda a, int id_contato){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("NOME",a.getNome());
        values.put("EMPRESA",a.getEmpresa());
        values.put("UF",a.getUf());

        long id = db.update("AGENDA", values, "id = ?", new String[]{String.valueOf(id_contato)});

        return id;
    }

    public Agenda getAgenda(int id){
        SQLiteDatabase db = this.getReadableDatabase();

        Agenda agenda = new Agenda();

        // Um cursor representa o resultado de uma query (busca)
        // e aponta para a linha selecionada
        Cursor cursor =
                db.rawQuery("SELECT * FROM AGENDA WHERE ID = ?", new String[]{String.valueOf(id)});

        if(cursor.getCount() > 0){ //getCount retorna o número de elementos da consulta
            cursor.moveToFirst();

            agenda.setId(cursor.getInt(0));
            agenda.setNome(cursor.getString(1));
            agenda.setEmpresa(cursor.getString(2));
            agenda.setUf(cursor.getString(3));
        }else{
            agenda.setId(0);
            agenda.setNome("");
            agenda.setEmpresa("");
            agenda.setUf("");
        }

        return agenda;
    }

    public int deleteAgenda(){
        SQLiteDatabase db = this.getWritableDatabase();
        int i = db.delete("AGENDA","1",null);

        return i;
    }



}


