package com.example.android.dicionarioxbeta1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ColorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);
    }
}